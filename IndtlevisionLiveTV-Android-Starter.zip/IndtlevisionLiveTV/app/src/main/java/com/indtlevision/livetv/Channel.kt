package com.indtlevision.livetv

data class Channel(
    val number: Int,
    val name: String,
    val category: String,
    // Add an official, authorized HLS (.m3u8) or DASH (.mpd) stream URL here.
    val streamUrl: String = ""
)
