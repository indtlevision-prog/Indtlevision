package com.indtlevision.livetv

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val name = intent.getStringExtra("channel_name") ?: "Live TV"
        val url = intent.getStringExtra("stream_url").orEmpty()
        window.statusBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val title = TextView(this).apply { text = name; textSize = 20f; setTextColor(Color.WHITE); setPadding(16, 18, 16, 12) }
        root.addView(title)
        if (url.isBlank()) {
            root.addView(TextView(this).apply {
                text = "This channel is a demo listing. Playback will work after an official, authorized stream URL is added by the app developer."
                textSize = 16f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(24, 24, 24, 24)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        } else {
            val view = PlayerView(this)
            root.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            player = ExoPlayer.Builder(this).build().also { exo ->
                view.player = exo
                exo.setMediaItem(MediaItem.fromUri(url))
                exo.prepare()
                exo.playWhenReady = true
            }
        }
        setContentView(root)
    }
    override fun onStop() { super.onStop(); player?.release(); player = null }
}
