package com.indtlevision.livetv

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val categories = listOf("All Channels", "News", "National TV", "Entertainment", "Movies", "Sports", "Devotional", "Regional")
    // These are sample listings only, not working broadcasts. Add verified official stream URLs and permission details before release.
    private val channels = listOf(
        Channel(1, "DD News", "News"),
        Channel(2, "DD National", "National TV"),
        Channel(3, "DD Sports", "Sports"),
        Channel(4, "DD Bihar", "Regional"),
        Channel(5, "DD Jharkhand", "Regional"),
        Channel(6, "Official devotional stream", "Devotional"),
        Channel(7, "Authorized entertainment stream", "Entertainment"),
        Channel(8, "Authorized movie stream", "Movies")
    )
    private lateinit var listArea: LinearLayout
    private var selectedCategory = "All Channels"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(6, 21, 47)
        window.navigationBarColor = Color.rgb(6, 21, 47)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(6, 21, 47))
            setPadding(18, 20, 18, 12)
        }
        val title = TextView(this).apply {
            text = "INDTLEVISION LIVE TV"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "India • Live channels • Your screen, your choice"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 14)
        }
        root.addView(title)
        root.addView(subtitle)
        val categoryScroll = HorizontalScrollViewCompat.create(this)
        val categoryRow = categoryScroll.firstChild as LinearLayout
        categories.forEach { category ->
            val button = Button(this).apply {
                text = category
                isAllCaps = false
                textSize = 12f
                setOnClickListener { selectedCategory = category; renderChannels() }
            }
            categoryRow.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = 7 })
        }
        root.addView(categoryScroll)
        val section = TextView(this).apply {
            text = "CHANNEL GUIDE"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(100, 181, 246))
            setPadding(0, 14, 0, 8)
        }
        root.addView(section)
        val scroll = ScrollView(this)
        listArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listArea)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val footer = TextView(this).apply {
            text = "Only official or licensed streams should be added before publishing."
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(4, 10, 4, 4)
        }
        root.addView(footer)
        setContentView(root)
        renderChannels()
    }

    private fun renderChannels() {
        listArea.removeAllViews()
        val visible = channels.filter { selectedCategory == "All Channels" || it.category == selectedCategory }
        visible.forEach { channel ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 12, 10, 12)
                setBackgroundColor(Color.rgb(14, 39, 76))
            }
            val number = TextView(this).apply {
                text = channel.number.toString().padStart(2, '0')
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(100, 181, 246))
                gravity = Gravity.CENTER
            }
            card.addView(number, LinearLayout.LayoutParams(46, ViewGroup.LayoutParams.WRAP_CONTENT))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(TextView(this).apply { text = channel.name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) })
            details.addView(TextView(this).apply { text = channel.category; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 3, 0, 0) })
            card.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(TextView(this).apply { text = "▶"; textSize = 22f; setTextColor(Color.WHITE) })
            card.setOnClickListener {
                startActivity(Intent(this, PlayerActivity::class.java).apply {
                    putExtra("channel_name", channel.name)
                    putExtra("stream_url", channel.streamUrl)
                })
            }
            listArea.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 9 })
        }
    }
}
