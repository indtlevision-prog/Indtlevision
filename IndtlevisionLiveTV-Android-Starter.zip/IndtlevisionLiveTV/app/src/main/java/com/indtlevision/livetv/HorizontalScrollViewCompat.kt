package com.indtlevision.livetv

import android.content.Context
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

object HorizontalScrollViewCompat {
    fun create(context: Context): HorizontalScrollView {
        val scroll = HorizontalScrollView(context)
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        scroll.addView(row)
        return scroll
    }
}
